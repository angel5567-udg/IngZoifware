const express = require("express");
const pool = require("./db"); // Ahora importamos db.js en lugar de server.js

const router = express.Router();

const limpiarDato = (dato) => dato?.trim();
const validarEmail = (email) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

// Obtener todos los clientes o uno específico
router.get("/", async (req, res) => {
    try {
        const { id } = req.query;
        const query = id ? "SELECT * FROM Cliente WHERE ID_Cliente = ?" : "SELECT * FROM Cliente";
        const [rows] = id ? await pool.query(query, [id]) : await pool.query(query);
        res.json({ status: "success", total: rows.length, data: rows });
    } catch (error) {
        res.status(500).json({ status: "error", message: "Error al obtener clientes", error });
    }
});

// Crear un cliente
// Crear un cliente
router.post("/", async (req, res) => {
  try {
      const { nombre, apellidos, telefono, email, contraseña, idTecnico } = req.body;

      if (!nombre || !email || !contraseña || !idTecnico) {
          throw new Error("Nombre, email, contraseña e ID_Tecnico son obligatorios");
      }

      if (!validarEmail(email)) {
          throw new Error("Email inválido");
      }

      // Consulta sin ID_Equipo
      const query = `INSERT INTO Cliente (NombrePila, Apellidos, NumTel, Email, Contraseña, ID_Tecnico) 
                     VALUES (?, ?, ?, ?, ?, ?)`;

      // Ejecutar la consulta
      const [result] = await pool.query(query, [nombre, apellidos, telefono, email, contraseña, idTecnico]);

      res.json({
          status: "success",
          message: "Cliente creado exitosamente",
          id: result.insertId
      });
  } catch (error) {
      res.status(400).json({ status: "error", message: error.message });
  }
});


// Actualizar un cliente
router.put("/", async (req, res) => {
    try {
        const { editId, editNombre, editApellidos, editTelefono, editEmail, editIdTecnico, editIdEquipo } = req.body;
        if (!editId) throw new Error("ID de cliente es obligatorio");
        if (editEmail && !validarEmail(editEmail)) throw new Error("Email inválido");

        const query = `UPDATE Cliente SET NombrePila = ?, Apellidos = ?, NumTel = ?, Email = ?, ID_Tecnico = ?, ID_Equipo = ? WHERE ID_Cliente = ?`;
        await pool.query(query, [editNombre, editApellidos, editTelefono, editEmail, editIdTecnico, editIdEquipo, editId]);

        res.json({ status: "success", message: "Cliente actualizado exitosamente" });
    } catch (error) {
        res.status(400).json({ status: "error", message: error.message });
    }
});

// Eliminar un cliente
router.delete("/", async (req, res) => {
    try {
        const { id } = req.body;
        if (!id) throw new Error("ID de cliente es obligatorio");

        const query = `DELETE FROM Cliente WHERE ID_Cliente = ?`;
        await pool.query(query, [id]);

        res.json({ status: "success", message: "Cliente eliminado exitosamente" });
    } catch (error) {
        res.status(400).json({ status: "error", message: error.message });
    }
});

module.exports = router;
