document.addEventListener('DOMContentLoaded', function() {
    const prevMonthBtn = document.getElementById('prev-month');
    const nextMonthBtn = document.getElementById('next-month');
    const monthNameEl = document.querySelector('.month-name');
    const calendarBody = document.querySelector('.calendar tbody');
    
    let currentDate = new Date();
    let currentMonth = currentDate.getMonth();
    let currentYear = currentDate.getFullYear();
    
    const monthNames = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 
                        'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];
    
    function updateCalendar() {
        monthNameEl.textContent = `${monthNames[currentMonth]} ${currentYear}`;
        calendarBody.innerHTML = '';
        
        let firstDay = new Date(currentYear, currentMonth, 1).getDay();
        let lastDate = new Date(currentYear, currentMonth + 1, 0).getDate();
        let prevLastDate = new Date(currentYear, currentMonth, 0).getDate();
        
        let days = [];
        
        for (let i = firstDay - 1; i >= 0; i--) {
            days.push({ day: prevLastDate - i, class: "prev-month" });
        }
        
        for (let i = 1; i <= lastDate; i++) {
            days.push({ day: i, class: "current-month" });
        }
        
        let nextDays = 42 - days.length;
        for (let i = 1; i <= nextDays; i++) {
            days.push({ day: i, class: "next-month" });
        }
        
        let row = document.createElement('tr');
        days.forEach((dayObj, index) => {
            let cell = document.createElement('td');
            cell.classList.add(dayObj.class);
            cell.innerHTML = `<div class="day-number">${dayObj.day}</div>`;
            
            row.appendChild(cell);
            
            if ((index + 1) % 7 === 0) {
                calendarBody.appendChild(row);
                row = document.createElement('tr');
            }
        });
    }

    prevMonthBtn.addEventListener('click', function() {
        currentMonth--;
        if (currentMonth < 0) {
            currentMonth = 11;
            currentYear--;
        }
        updateCalendar();
    });

    nextMonthBtn.addEventListener('click', function() {
        currentMonth++;
        if (currentMonth > 11) {
            currentMonth = 0;
            currentYear++;
        }
        updateCalendar();
    });

    updateCalendar();
});