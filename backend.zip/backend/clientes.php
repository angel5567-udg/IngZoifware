<?php
// Incluir archivo de conexión
include '../backend/conexion.php';

// Configuraciones de headers para API REST
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

// Función para validar y limpiar datos
function limpiarDato($dato) {
    $dato = trim($dato);
    $dato = stripslashes($dato);
    $dato = htmlspecialchars($dato);
    return $dato;
}

// Función para validar email
function validarEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

// Manejar diferentes métodos HTTP
$metodo = $_SERVER['REQUEST_METHOD'];

switch($metodo) {
    case 'GET':
        obtenerClientes($conn);
        break;
    
    case 'POST':
        crearCliente($conn);
        break;
    
    case 'PUT':
        actualizarCliente($conn);
        break;
    
    case 'DELETE':
        eliminarCliente($conn);
        break;
}

function obtenerClientes($conn) {
    try {
        // Verificar si se solicita un cliente específico
        $id = isset($_GET['id']) ? intval($_GET['id']) : null;
        
        $consulta = $id 
            ? "SELECT * FROM Clientes WHERE ID_Cliente = ?" 
            : "SELECT * FROM Clientes";
        
        $stmt = $conn->prepare($consulta);
        
        if ($id) {
            $stmt->bind_param("i", $id);
        }
        
        $stmt->execute();
        $resultado = $stmt->get_result();
        
        $clientes = [];
        while ($fila = $resultado->fetch_assoc()) {
            $clientes[] = $fila;
        }
        
        echo json_encode([
            'status' => 'success',
            'total' => count($clientes),
            'data' => $clientes
        ]);
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'status' => 'error',
            'message' => 'Error al obtener clientes: ' . $e->getMessage()
        ]);
    }
}

function crearCliente($conn) {
    $datos = json_decode(file_get_contents('php://input'), true);
    
    try {
        // Validaciones de datos
        if (empty($datos['nombre']) || empty($datos['email'])) {
            throw new Exception("Nombre y email son obligatorios");
        }
        
        if (!validarEmail($datos['email'])) {
            throw new Exception("Email inválido");
        }
        
        $consulta = $conn->prepare(
            "INSERT INTO Clientes (
                ID_Cliente, 
                Nombre, 
                Apellidos, 
                Telefono, 
                Email, 
                ID_Tecnico, 
                ID_Equipo
            ) VALUES (?, ?, ?, ?, ?, ?, ?)"
        );
        
        $consulta->bind_param(
            "issssss", 
            $datos['idCliente'],
            limpiarDato($datos['nombre']),
            limpiarDato($datos['apellidos']),
            limpiarDato($datos['telefono']),
            limpiarDato($datos['email']),
            $datos['idTecnico'],
            $datos['idEquipo']
        );
        
        $resultado = $consulta->execute();
        
        if ($resultado) {
            echo json_encode([
                'status' => 'success',
                'message' => 'Cliente creado exitosamente',
                'id' => $datos['idCliente']
            ]);
        } else {
            throw new Exception("Error al crear cliente");
        }
    } catch (Exception $e) {
        http_response_code(400);
        echo json_encode([
            'status' => 'error',
            'message' => $e->getMessage()
        ]);
    }
}

function actualizarCliente($conn) {
    $datos = json_decode(file_get_contents('php://input'), true);
    
    try {
        if (empty($datos['editId'])) {
            throw new Exception("ID de cliente es obligatorio");
        }
        
        if (!empty($datos['editEmail']) && !validarEmail($datos['editEmail'])) {
            throw new Exception("Email inválido");
        }
        
        $consulta = $conn->prepare(
            "UPDATE Clientes SET 
                Nombre = ?, 
                Apellidos = ?, 
                Telefono = ?, 
                Email = ?, 
                ID_Tecnico = ?, 
                ID_Equipo = ?
             WHERE ID_Cliente = ?"
        );
        
        $consulta->bind_param(
            "ssssssi", 
            limpiarDato($datos['editNombre']),
            limpiarDato($datos['editApellidos']),
            limpiarDato($datos['editTelefono']),
            limpiarDato($datos['editEmail']),
            $datos['editIdTecnico'],
            $datos['editIdEquipo'],
            $datos['editId']
        );
        
        $resultado = $consulta->execute();
        
        if ($resultado) {
            echo json_encode([
                'status' => 'success',
                'message' => 'Cliente actualizado exitosamente'
            ]);
        } else {
            throw new Exception("Error al actualizar cliente");
        }
    } catch (Exception $e) {
        http_response_code(400);
        echo json_encode([
            'status' => 'error',
            'message' => $e->getMessage()
        ]);
    }
}

function eliminarCliente($conn) {
    $datos = json_decode(file_get_contents('php://input'), true);
    
    try {
        if (empty($datos['id'])) {
            throw new Exception("ID de cliente es obligatorio");
        }
        
        $consulta = $conn->prepare("DELETE FROM Clientes WHERE ID_Cliente = ?");
        $consulta->bind_param("i", $datos['id']);
        
        $resultado = $consulta->execute();
        
        if ($resultado) {
            echo json_encode([
                'status' => 'success',
                'message' => 'Cliente eliminado exitosamente'
            ]);
        } else {
            throw new Exception("Error al eliminar cliente");
        }
    } catch (Exception $e) {
        http_response_code(400);
        echo json_encode([
            'status' => 'error',
            'message' => $e->getMessage()
        ]);
    }
}

// Cerrar conexión
$conn->close();
?>