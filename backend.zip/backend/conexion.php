<?php
$host = "localhost";      // Servidor local
$usuario = "root";        // Usuario por defecto en XAMPP
$password = "";           // Contraseña vacía por defecto
$basedatos = "ingsoft";   // Nombre de su base de datos

// Crear conexión
$conn = new mysqli($host, $usuario, $password, $basedatos);

// Verificar conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}
?>