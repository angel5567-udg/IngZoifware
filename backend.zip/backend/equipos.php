<?php
// config.php - Database Connection Configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'your_username');
define('DB_PASS', 'your_password');
define('DB_NAME', 'tech_control_db');

// database.php - Database Connection and Utility Functions
class Database {
    private $conn;

    public function __construct() {
        try {
            $this->conn = new PDO(
                "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, 
                DB_USER, 
                DB_PASS
            );
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch(PDOException $e) {
            die("Error de conexión: " . $e->getMessage());
        }
    }

    public function getConnection() {
        return $this->conn;
    }
}

// equipos.php - Equipment Management Class
class Equipos {
    private $conn;
    private $table_name = "equipos";

    public function __construct($db) {
        $this->conn = $db;
    }

    // Método para listar todos los equipos
    public function listarEquipos() {
        $query = "SELECT 
            id_equipo, 
            id_marca, 
            marca, 
            id_modelo, 
            modelo, 
            id_tecnico, 
            num_serie, 
            id_tipo, 
            tipo 
            FROM " . $this->table_name;
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Método para agregar un nuevo equipo
    public function agregarEquipo($datos) {
        $query = "INSERT INTO " . $this->table_name . " 
                  (id_marca, marca, id_modelo, modelo, id_tecnico, 
                   num_serie, id_tipo, tipo) 
                  VALUES 
                  (:id_marca, :marca, :id_modelo, :modelo, :id_tecnico, 
                   :num_serie, :id_tipo, :tipo)";
        
        $stmt = $this->conn->prepare($query);
        
        // Sanitizar y bindear parámetros
        $stmt->bindParam(":id_marca", $datos['idMarca']);
        $stmt->bindParam(":marca", $datos['Marca']);
        $stmt->bindParam(":id_modelo", $datos['idModelo']);
        $stmt->bindParam(":modelo", $datos['modelo']);
        $stmt->bindParam(":id_tecnico", $datos['idTecnico']);
        $stmt->bindParam(":num_serie", $datos['numSerie']);
        $stmt->bindParam(":id_tipo", $datos['idTipo']);
        $stmt->bindParam(":tipo", $datos['tipo']);
        
        return $stmt->execute();
    }

    // Método para actualizar un equipo
    public function actualizarEquipo($id, $datos) {
        $query = "UPDATE " . $this->table_name . " 
                  SET id_marca = :id_marca, 
                      marca = :marca, 
                      id_modelo = :id_modelo, 
                      modelo = :modelo, 
                      id_tecnico = :id_tecnico, 
                      num_serie = :num_serie, 
                      id_tipo = :id_tipo, 
                      tipo = :tipo 
                  WHERE id_equipo = :id_equipo";
        
        $stmt = $this->conn->prepare($query);
        
        $stmt->bindParam(":id_equipo", $id);
        $stmt->bindParam(":id_marca", $datos['idMarca']);
        $stmt->bindParam(":marca", $datos['Marca']);
        $stmt->bindParam(":id_modelo", $datos['idModelo']);
        $stmt->bindParam(":modelo", $datos['modelo']);
        $stmt->bindParam(":id_tecnico", $datos['idTecnico']);
        $stmt->bindParam(":num_serie", $datos['numSerie']);
        $stmt->bindParam(":id_tipo", $datos['idTipo']);
        $stmt->bindParam(":tipo", $datos['tipo']);
        
        return $stmt->execute();
    }

    // Método para eliminar un equipo
    public function eliminarEquipo($id) {
        $query = "DELETE FROM " . $this->table_name . " WHERE id_equipo = :id_equipo";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id_equipo", $id);
        
        return $stmt->execute();
    }

    // Método para buscar equipos
    public function buscarEquipos($termino) {
        $query = "SELECT * FROM " . $this->table_name . " 
                  WHERE marca LIKE :termino OR 
                        modelo LIKE :termino OR 
                        num_serie LIKE :termino";
        
        $stmt = $this->conn->prepare($query);
        $termino_like = "%{$termino}%";
        $stmt->bindParam(":termino", $termino_like);
        
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

// ajax_equipos.php - Endpoint para solicitudes AJAX
require_once 'config.php';
require_once 'database.php';
require_once 'equipos.php';

header('Content-Type: application/json');

$database = new Database();
$db = $database->getConnection();
$equipos = new Equipos($db);

$action = $_GET['action'] ?? $_POST['action'] ?? null;

switch($action) {
    case 'listar':
        echo json_encode($equipos->listarEquipos());
        break;
    
    case 'agregar':
        $resultado = $equipos->agregarEquipo($_POST);
        echo json_encode(['success' => $resultado]);
        break;
    
    case 'actualizar':
        $id = $_POST['id_equipo'];
        $resultado = $equipos->actualizarEquipo($id, $_POST);
        echo json_encode(['success' => $resultado]);
        break;
    
    case 'eliminar':
        $id = $_POST['id_equipo'];
        $resultado = $equipos->eliminarEquipo($id);
        echo json_encode(['success' => $resultado]);
        break;
    
    case 'buscar':
        $termino = $_GET['termino'];
        echo json_encode($equipos->buscarEquipos($termino));
        break;
    
    default:
        echo json_encode(['error' => 'Acción no válida']);
        break;
}
?>