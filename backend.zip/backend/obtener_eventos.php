<?php
include 'conexion.php';

$sql = "SELECT * FROM eventos";
$result = $conn->query($sql);

$eventos = array();
while ($row = $result->fetch_assoc()) {
    $eventos[] = $row;
}

echo json_encode($eventos);
$conn->close();
?>
